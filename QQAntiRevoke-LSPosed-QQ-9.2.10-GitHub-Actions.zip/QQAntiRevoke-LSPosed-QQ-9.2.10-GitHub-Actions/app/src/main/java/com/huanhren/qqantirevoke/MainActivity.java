package com.huanhren.qqantirevoke;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private SharedPreferences preferences;
    private boolean worldReadableAvailable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(0xFFFFFFFF);
        window.setNavigationBarColor(0xFFFFFFFF);

        preferences = openPreferences();
        setContentView(buildContent());
    }

    @SuppressWarnings("deprecation")
    private SharedPreferences openPreferences() {
        try {
            SharedPreferences prefs = getSharedPreferences(
                    ModulePrefs.PREF_FILE,
                    Context.MODE_WORLD_READABLE
            );
            worldReadableAvailable = true;
            return prefs;
        } catch (SecurityException ignored) {
            worldReadableAvailable = false;
            return getSharedPreferences(ModulePrefs.PREF_FILE, Context.MODE_PRIVATE);
        }
    }

    private View buildContent() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(32));
        scrollView.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        root.addView(title("QQ 防撤回 · LSPosed"));
        root.addView(body("目标环境：Android 15 · QQ 9.2.10 · LSPosed Zygisk\n\n"
                + "工作方式：让 QQ 的撤回入口继续执行以生成小灰条，只在同一线程的撤回调用链中阻止原消息移除。"));

        Switch enabled = option(
                "启用防撤回",
                "总开关。修改后需要强制停止并重新打开 QQ。",
                ModulePrefs.KEY_ENABLED,
                ModulePrefs.DEFAULT_ENABLED
        );
        root.addView(enabled);

        Switch aggressive = option(
                "兼容模式",
                "当消息标识无法精确匹配时，仍拦截撤回调用链内符合签名的 V/Z 移除方法。适配成功率更高，但风险略高。",
                ModulePrefs.KEY_AGGRESSIVE,
                ModulePrefs.DEFAULT_AGGRESSIVE
        );
        root.addView(aggressive);

        Switch diagnostics = option(
                "详细诊断日志",
                "在 LSPosed 日志中输出命中的类、方法签名和拦截原因，不记录聊天正文。",
                ModulePrefs.KEY_DIAGNOSTICS,
                ModulePrefs.DEFAULT_DIAGNOSTICS
        );
        root.addView(diagnostics);

        TextView state = body(worldReadableAvailable
                ? "设置存储：LSPosed XSharedPreferences 已可用。"
                : "设置存储：当前未获得 LSPosed 共享偏好支持。先在 LSPosed 中启用本模块并勾选 QQ，重启或强制停止本模块后再次打开。Hook 端仍会使用默认设置。"
        );
        state.setPadding(0, dp(14), 0, dp(14));
        root.addView(state);

        Button defaults = new Button(this);
        defaults.setText("恢复推荐设置");
        defaults.setOnClickListener(v -> {
            preferences.edit()
                    .putBoolean(ModulePrefs.KEY_ENABLED, ModulePrefs.DEFAULT_ENABLED)
                    .putBoolean(ModulePrefs.KEY_AGGRESSIVE, ModulePrefs.DEFAULT_AGGRESSIVE)
                    .putBoolean(ModulePrefs.KEY_DIAGNOSTICS, ModulePrefs.DEFAULT_DIAGNOSTICS)
                    .apply();
            recreate();
        });
        root.addView(defaults);

        root.addView(section("安装后操作"));
        root.addView(body("1. 在 LSPosed 模块页面启用本模块。\n"
                + "2. 作用域只勾选 QQ（com.tencent.mobileqq）。\n"
                + "3. 强制停止 QQ，再重新打开。\n"
                + "4. 在 LSPosed 日志搜索 [QQAntiRevoke]。\n"
                + "5. 先用不重要的测试消息验证，不要直接用于重要聊天。"));

        root.addView(section("重要说明"));
        root.addView(body("QQ 的类名和混淆方法会随版本改变。工程已针对你提供的 BaseMessageManager / C2C / 群聊管理器路径实现，并增加了签名过滤和崩溃保护；但只有拿到 QQ 9.2.10 的真实 DEX 或真机日志后，才能确认 Hook 点百分之百命中。"));

        scrollView.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getInsets(WindowInsets.Type.statusBars()).top;
            int bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            root.setPadding(dp(22), dp(22) + top, dp(22), dp(32) + bottom);
            return insets;
        });
        return scrollView;
    }

    private Switch option(String title, String description, String key, boolean defaultValue) {
        Switch view = new Switch(this);
        view.setText(title + "\n" + description);
        view.setTextSize(16f);
        view.setPadding(0, dp(10), 0, dp(10));
        view.setChecked(preferences.getBoolean(key, defaultValue));
        view.setOnCheckedChangeListener((CompoundButton buttonView, boolean isChecked) -> {
            preferences.edit().putBoolean(key, isChecked).apply();
            Toast.makeText(this, "已保存；强制停止并重新打开 QQ 后生效", Toast.LENGTH_SHORT).show();
        });
        return view;
    }

    private TextView title(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(26f);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setPadding(0, 0, 0, dp(12));
        return view;
    }

    private TextView section(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(19f);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setPadding(0, dp(22), 0, dp(8));
        return view;
    }

    private TextView body(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(15f);
        view.setLineSpacing(0f, 1.18f);
        return view;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
